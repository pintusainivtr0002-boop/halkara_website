HALKARA WEBSITE
Files:
- index.html
- profile.png
- photo1.jpg
- photo2.png
- photo3.png

Public website:
Upload all files to a static hosting service (for example GitHub Pages, Netlify, or another provider).
Keep the image files in the same folder as index.html.
